# Báo cáo tiến độ NCKH, cập nhật 31/10/2026

PDF để nộp: `Bao_cao_tien_do_NCKH_UAV_2026-10-31.pdf` ở thư mục `reports/` của project và ở gốc ZIP nguồn.

Bản này đối chiếu thuyết minh RQ1–RQ4, trình bày phương pháp và kết quả core matrix, bổ sung bootstrap ghép cặp theo seed, false-stable, routing offline, nhãn một lớp và công việc còn lại. Không phải báo cáo nghiệm thu. Không dùng các bảng stage7/closed-loop cũ làm kết quả đã xác nhận sau audit. Không thực hiện huấn luyện/mô phỏng lại trong lần cập nhật báo cáo này.

Lời văn đã được biên tập bằng skill humanizer theo yêu cầu của nhóm. Xem `BIEN_TAP_HUMANIZER.md` để đối chiếu bản nháp, lượt rà soát cuối và ví dụ câu đã sửa. Bản PDF giữ số liệu và công thức của báo cáo tiến độ trước khi biên tập.

## Dùng ZIP nguồn

Giải nén toàn bộ, giữ cấu trúc `reports/` và `outputs/`. ZIP chỉ chứa metadata của mô hình để kiểm tra split, không chứa checkpoint và dữ liệu mô phỏng lớn.

Từ thư mục gốc đã giải nén, với Python có numpy, pandas, matplotlib:

```powershell
py reports/core_matrix_bursty_fixed/generate_progress_tables.py
py reports/core_matrix_bursty_fixed/generate_figures.py
```

Biểu đồ có sẵn nên không bắt buộc tạo lại khi biên dịch. Trong thư mục `reports/core_matrix_bursty_fixed/`, tạo thư mục `build` nếu chưa có và chạy hai lần:

```powershell
xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex
```

PDF được sinh tại `build/main.pdf`. Cần XeLaTeX, font Times New Roman hoặc Noto Serif và các package LaTeX khai báo trong nguồn. Thuyết minh gốc không nằm trong ZIP; phần đối chiếu nội dung đã có trong chương 5.

## Kiểm tra đã thực hiện

- Đủ 6.720 metric, 210 run, 32 tổ hợp/run; không trùng khóa hoặc thiếu Macro-F1.
- Trung bình metric từng run khớp aggregate; 21/21 manipulation checks đạt.
- Đủ 240 metadata; mỗi fold có 189 run nguồn train/validation, 21 run test, không giao seed.
- Tạo lại bảng chênh lệch bằng bootstrap 20.000 lần trên 10 seed, RNG seed 42.
- XeLaTeX biên dịch; kiểm tra khóa tham chiếu/trích dẫn trong nguồn và log cuối không có undefined reference, missing character, overfull box hoặc LaTeX error.
- Kiểm tra trực quan PDF 20 trang, gồm bìa, mục lục, bảng, biểu đồ và phụ lục.

MiKTeX trên máy có cảnh báo chưa kiểm tra cập nhật. Công cụ latexmk không chạy được trong môi trường này; PDF được biên dịch trực tiếp bằng XeLaTeX. Kiểm tra bibliography dùng cả các mục `bibitem` nội tuyến vì công cụ kiểm tra `.bib` riêng không hỗ trợ kiểu bibliography của template.

Chưa xác minh mẫu hành chính tiến độ riêng của khoa, ngày phê duyệt đề tài, lịch nghiệm thu, provenance toàn bộ artifact cũ hoặc tái huấn luyện pipeline. Báo cáo không tự đặt phần trăm hoàn thành và không diễn giải routing offline như PDR đầu cuối.
