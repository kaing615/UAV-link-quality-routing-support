"""Recompute progress-report evidence from existing metrics; no training is performed."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent


def main():
    runs = pd.read_csv(ROOT / 'metrics_runs.csv')
    aggregate = pd.read_csv(ROOT / 'metrics_aggregate.csv')
    checks = pd.read_csv(ROOT / 'manipulation_checks.csv')
    keys = ['run_name', 'model_id', 'target', 'horizon']
    assert len(runs) == 6720 and not runs.duplicated(keys).any()
    assert runs.run_name.nunique() == 210 and runs.seed.nunique() == 10
    assert runs.groupby('run_name').size().eq(32).all()
    assert runs.macro_f1.notna().all()
    assert len(checks) == 21 and checks['pass'].all()
    recomputed = runs.groupby(['condition', 'model_id', 'target', 'horizon']).macro_f1.mean()
    recorded = aggregate.set_index(['condition', 'model_id', 'target', 'horizon']).macro_f1_mean
    assert np.allclose(recomputed.sort_index(), recorded.sort_index())
    metadata = list((ROOT.parents[1] / 'outputs/core_matrix_bursty_fixed').glob('*/*/k*/seed*/metadata.json'))
    assert len(metadata) == 240
    for path in metadata:
        m = json.loads(path.read_text(encoding='utf-8'))
        train, test = m['train_runs'], m['test_runs']
        assert len(train) == 189 and len(test) == 21
        assert not {r.rsplit('_s', 1)[-1] for r in train} & {r.rsplit('_s', 1)[-1] for r in test}

    paired = runs.pivot(index=['target', 'horizon', 'seed', 'condition'], columns='model_id', values='macro_f1')
    paired['delta'] = paired['edge-sage'] - paired['xgb']
    rng = np.random.default_rng(42)
    effects = []
    for (target, horizon), group in paired.groupby(['target', 'horizon']):
        seed_effect = group.groupby('seed').delta.mean().to_numpy()
        condition_effect = group.groupby('condition').delta.mean()
        ci = np.quantile(rng.choice(seed_effect, (20000, len(seed_effect)), replace=True).mean(axis=1), [.025, .975])
        effects.append(dict(target=target, horizon=horizon, delta=seed_effect.mean(), ci_low=ci[0], ci_high=ci[1],
                            wins=int((condition_effect > 1e-12).sum()), ties=int((condition_effect.abs() <= 1e-12).sum()),
                            losses=int((condition_effect < -1e-12).sum())))
    effects = pd.DataFrame(effects)
    effects.to_csv(ROOT / 'progress_paired_effects.csv', index=False)
    means = aggregate.groupby(['target', 'horizon', 'model_id']).mean(numeric_only=True)
    condition_means = runs.groupby(['target', 'horizon', 'condition', 'model_id']).macro_f1.mean()
    excluded = condition_means.loc[condition_means.index.get_level_values('condition') != 'event_control'].groupby(['target', 'horizon', 'model_id']).mean()
    excluded.rename('macro_f1_mean').to_csv(ROOT / 'progress_two_class_macro_f1.csv')
    text = [r'\begin{table}[H]\centering\small',
            r'\begin{tabular}{llrrr}\toprule Target & $k$ & $\Delta$ (điểm \%) & CI 95\% (điểm \%) & Thắng/hòa/thua\\\midrule']
    for row in effects.itertuples():
        text.append(f'{row.target} & {row.horizon} & {100*row.delta:.2f} & [{100*row.ci_low:.2f}; {100*row.ci_high:.2f}] & {row.wins}/{row.ties}/{row.losses}'+r'\\')
    text += [r'\bottomrule\end{tabular}', r'\caption{Chênh lệch Macro-F1 giữa Edge-SAGE và XGBoost. Số điều kiện thắng/hòa/thua dựa trên trung bình của từng điều kiện trong 21 điều kiện.}\label{tab:paired-progress}\end{table}']
    text += [r'\begin{table}[H]\centering\small', r'\begin{tabular}{llrrrr}\toprule & & \multicolumn{2}{c}{False-stable} & \multicolumn{2}{c}{Lifetime (bước)}\\',
             r'Target & $k$ & Edge-SAGE & XGBoost & Edge-SAGE & XGBoost\\\midrule']
    for row in effects.itertuples():
        s, x = (means.loc[(row.target, row.horizon, model)] for model in ['edge-sage', 'xgb'])
        text.append(f'{row.target} & {row.horizon} & {s.false_stable_mean:.4f} & {x.false_stable_mean:.4f} & {s.route_lifetime_mean:.4f} & {x.route_lifetime_mean:.4f}'+r'\\')
    text += [r'\bottomrule\end{tabular}', r'\caption{Tỷ lệ ổn định giả và tuổi thọ tuyến ngoại tuyến, lấy trung bình theo điều kiện. False-stable thấp hơn là tốt hơn.}\label{tab:routing-progress}\end{table}']
    text += [r'\begin{table}[H]\centering\small', r'\begin{tabular}{llrr}\toprule Target & $k$ & Edge-SAGE & XGBoost\\\midrule']
    for row in effects.itertuples():
        s, x = (excluded.loc[(row.target, row.horizon, model)] for model in ['edge-sage', 'xgb'])
        text.append(f'{row.target} & {row.horizon} & {s:.4f} & {x:.4f}'+r'\\')
    text += [r'\bottomrule\end{tabular}', r'\caption{Phân tích bổ sung trên 20 điều kiện có đủ hai lớp, loại event\_control; không thay thế bảng chính 21 điều kiện.}\label{tab:two-class-progress}\end{table}']
    (ROOT / 'progress_tables.tex').write_text('\n'.join(text)+'\n', encoding='utf-8')
    print('PASS: coverage, aggregates, 240 metadata seed splits; wrote progress tables and two CSVs.')


if __name__ == '__main__':
    main()
