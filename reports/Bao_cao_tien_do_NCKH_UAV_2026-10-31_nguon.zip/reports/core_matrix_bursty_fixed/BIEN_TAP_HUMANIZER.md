# Ghi chú biên tập lời văn

Áp dụng skill humanizer cho báo cáo tiến độ ngày 31/10/2026. Giữ giọng báo cáo học thuật của nhóm nghiên cứu; không thêm trải nghiệm, nhận xét cá nhân hoặc kết quả thí nghiệm mới.

## Bản nháp biên tập

Ví dụ ở phần phương pháp:

> Các điều kiện dùng chung seed có liên quan với nhau, nên 210 lượt mô phỏng không phải 210 đơn vị ngẫu nhiên độc lập. Để so sánh Edge-SAGE với XGBoost, nhóm tính chênh lệch Macro-F1 trên từng cặp điều kiện/seed rồi lấy trung bình 21 điều kiện trong mỗi seed.

Bản nháp đã thay các cụm “condition mean”, “provenance”, “endpoint” và “policy routing” trong phần diễn giải bằng cách gọi tiếng Việt. Tên mô hình, tên chỉ số, định danh tệp và thuật ngữ cần đối chiếu với mã nguồn vẫn được giữ.

## What makes the below so obviously AI generated?

Những điểm còn thấy sau lượt sửa đầu:

- Một số câu vẫn xếp liên tiếp nhiều thuật ngữ và điều kiện, khiến nhịp văn nặng.
- Phần kế hoạch dùng nhãn in đậm kèm “Đầu ra” lặp lại ở mọi mục.
- Các đoạn kết luận nhắc lại giới hạn theo cùng một khuôn, trong khi có thể nói thẳng bằng trường hợp cụ thể.

## Now make it not obviously AI generated.

Ví dụ bản cuối ở phần giới hạn:

> Lifetime có giới hạn cửa sổ khác nhau ở k=1 và k=5, nên tăng lifetime giữa hai mốc này chưa chứng minh tuyến bền hơn. Các chỉ số ngoại tuyến cũng chưa thay thế được PDR và độ trễ đầu cuối đo bằng lưu lượng gói tin. Nhóm chưa sử dụng các kết quả routing replay/closed-loop khác trong kho mã vì cần xác minh chúng đã được tạo lại sau đợt rà soát lỗi hay chưa.

Toàn văn sau biên tập nằm trong `main.tex`, `progress_methods.tex`, `progress_results.tex` và `progress_status.tex`. Phần chú thích bảng được sửa trong `generate_progress_tables.py` để lần tạo lại bảng sau cũng dùng cùng lời văn.

Đã bỏ các nhãn in đậm lặp ở kế hoạch, viết rõ chủ thể thực hiện và chuyển những nhận xét chung thành mô tả có số liệu hoặc phạm vi cụ thể. Các công thức nhãn, giá trị kết quả và trích dẫn giữ nguyên. Đã xuất lại PDF và cập nhật ZIP nguồn.

Ghi chú này phục vụ theo dõi biên tập, không đưa vào nội dung PDF nộp tiến độ. Việc biên tập không bảo đảm một kết quả nào từ công cụ nhận diện văn bản AI.
