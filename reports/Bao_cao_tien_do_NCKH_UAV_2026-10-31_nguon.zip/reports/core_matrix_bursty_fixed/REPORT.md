# Core matrix results

Status: COMPLETE

210 runs; 21 conditions; 10 paired seeds/condition.

Evaluation: held seed; all conditions sharing a test seed are excluded from training. Purge-boundary times are evaluated only on wholly held-out seeds.

CI: bootstrap over paired seed units, never edges or sessions. PR-AUC is undefined for one-class runs; see undefined_pr_auc.csv. Bridge metrics concern observed structural bridges and intergroup cut edges; novel unseen links are outside support. Queue delay is MAC queue residence including backoff/retries/service; it is not IP end-to-end delay. Offered load is aggregate payload divided by nominal 6 Mbps PHY rate, not achieved goodput.
