"""Generate report figures from the completed core-matrix aggregate metrics."""
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "metrics_aggregate.csv"
FIGURES = ROOT / "figures"
HORIZONS = (1, 2, 3, 5)
MODELS = ("edge-sage", "xgb", "logreg", "persistence")
MODEL_LABELS = {
    "edge-sage": "Edge-SAGE",
    "xgb": "XGBoost",
    "logreg": "Logistic regression",
    "persistence": "Persistence",
}
MODEL_COLORS = {
    "edge-sage": "#177e89",
    "xgb": "#d1495b",
    "logreg": "#4c6ef5",
    "persistence": "#7a7a7a",
}


def load_rows() -> list[dict[str, str]]:
    with SOURCE.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    expected = 21 * 2 * len(HORIZONS) * len(MODELS)
    if len(rows) != expected:
        raise ValueError(f"Expected {expected} aggregate rows, found {len(rows)}")
    if not all(row["n_seeds"] == "10" for row in rows):
        raise ValueError("Every aggregate row must contain ten paired seeds")
    return rows


def condition_means(rows: list[dict[str, str]]) -> dict[tuple[str, int, str], float]:
    grouped: dict[tuple[str, int, str], list[float]] = defaultdict(list)
    for row in rows:
        value = float(row["macro_f1_mean"])
        if not 0 <= value <= 1:
            raise ValueError(f"Invalid macro-F1 value: {value}")
        grouped[(row["target"], int(row["horizon"]), row["model_id"])].append(value)
    expected = len(HORIZONS) * 2 * len(MODELS)
    if len(grouped) != expected or any(len(values) != 21 for values in grouped.values()):
        raise ValueError("Expected 21 controlled conditions per target, horizon, and model")
    return {key: float(np.mean(values)) for key, values in grouped.items()}


def plot_multihorizon(means: dict[tuple[str, int, str], float]) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), sharey=False)
    for axis, target, title in zip(axes, ("qos", "survival"), ("QoS prediction", "Link survival prediction"), strict=True):
        for model in MODELS:
            values = [means[(target, horizon, model)] for horizon in HORIZONS]
            axis.plot(HORIZONS, values, marker="o", linewidth=2.3, markersize=5.8,
                      color=MODEL_COLORS[model], label=MODEL_LABELS[model])
        axis.set_title(title, fontweight="bold")
        axis.set_xlabel("Prediction horizon k")
        axis.set_ylabel("Mean macro-F1 across 21 conditions")
        axis.set_xticks(HORIZONS)
        axis.set_ylim(0.40, 1.0)
        axis.grid(axis="y", alpha=0.25)
    fig.legend(*axes[1].get_legend_handles_labels(), loc="lower center", ncol=4,
               frameon=False, bbox_to_anchor=(0.5, -0.03))
    fig.suptitle("Held-seed performance across prediction horizons", fontweight="bold", y=1.02)
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    fig.savefig(FIGURES / "multihorizon_macro_f1.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def plot_margin(means: dict[tuple[str, int, str], float]) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(11.8, 4.2), sharey=True)
    for axis, target, title in zip(axes, ("qos", "survival"), ("QoS", "Link survival"), strict=True):
        margins = [means[(target, horizon, "edge-sage")] - means[(target, horizon, "xgb")]
                   for horizon in HORIZONS]
        colors = ["#177e89" if margin >= 0 else "#d1495b" for margin in margins]
        axis.bar([str(horizon) for horizon in HORIZONS], margins, color=colors, width=0.58)
        axis.axhline(0, color="#303030", linewidth=0.8)
        axis.set_title(title, fontweight="bold")
        axis.set_xlabel("Prediction horizon k")
        axis.set_ylabel("Macro-F1 difference: Edge-SAGE - XGBoost")
        axis.grid(axis="y", alpha=0.25)
        for index, margin in enumerate(margins):
            axis.text(index, margin + (0.002 if margin >= 0 else -0.005), f"{margin:+.3f}",
                      ha="center", va="bottom" if margin >= 0 else "top", fontsize=9)
    fig.suptitle("Edge-SAGE margin over the strongest classical baseline", fontweight="bold", y=1.02)
    fig.tight_layout()
    fig.savefig(FIGURES / "edge_sage_vs_xgb.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def plot_condition_heatmap(rows: list[dict[str, str]]) -> None:
    selected = {(row["target"], int(row["horizon"]), row["condition"]): float(row["macro_f1_mean"])
                for row in rows if row["model_id"] == "edge-sage"}
    order = {"fast3d": 0, "density": 1, "partition": 2, "load": 3}
    conditions = sorted({row["condition"] for row in rows},
                        key=lambda condition: next((order[row["family"]], condition)
                                                   for row in rows if row["condition"] == condition))
    coordinates = (("qos", 1, "QoS k=1"), ("qos", 5, "QoS k=5"),
                   ("survival", 1, "Survival k=1"), ("survival", 5, "Survival k=5"))
    matrix = np.array([[selected[(target, horizon, condition)] for condition in conditions]
                       for target, horizon, _ in coordinates])
    fig, axis = plt.subplots(figsize=(14, 3.7))
    image = axis.imshow(matrix, aspect="auto", cmap="YlGnBu", vmin=0.55, vmax=0.95)
    axis.set_title("Edge-SAGE macro-F1 by controlled condition", fontweight="bold", pad=12)
    axis.set_xticks(range(len(conditions)), conditions, rotation=45, ha="right", fontsize=8)
    axis.set_yticks(range(len(coordinates)), [label for _, _, label in coordinates])
    for row_index, row in enumerate(matrix):
        for column_index, value in enumerate(row):
            axis.text(column_index, row_index, f"{value:.2f}", ha="center", va="center", fontsize=7,
                      color="white" if value < 0.74 else "black")
    colorbar = fig.colorbar(image, ax=axis, pad=0.02)
    colorbar.set_label("Macro-F1")
    fig.tight_layout()
    fig.savefig(FIGURES / "edge_sage_condition_heatmap.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    FIGURES.mkdir(exist_ok=True)
    rows = load_rows()
    means = condition_means(rows)
    plot_multihorizon(means)
    plot_margin(means)
    plot_condition_heatmap(rows)
    print(f"[OK] wrote figures to {FIGURES}")


if __name__ == "__main__":
    main()
